
from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

# AGV simulation state
agv = {
    "x": 0,
    "y": 0,
    "direction": "NORTH",
    "speed": 0,
    "obstacle": False,
    "emergency": False,
    "distance": 0
}


def get_status():
    if agv["emergency"]:
        return "EMERGENCY STOP"
    if agv["obstacle"]:
        return "OBSTACLE DETECTED"
    if agv["speed"] > 0:
        return "RUNNING"
    return "READY"


def can_move():
    return not agv["obstacle"] and not agv["emergency"]


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/state", methods=["GET"])
def get_state():
    return jsonify({
        **agv,
        "status": get_status(),
        "safe": can_move()
    })


@app.route("/api/command", methods=["POST"])
def command():
    data = request.get_json(silent=True) or {}
    action = data.get("action")

    if action == "start":
        if not can_move():
            return jsonify({"error": "Safety condition prevents movement"}), 400
        agv["speed"] = 40

    elif action == "stop":
        agv["speed"] = 0

    elif action == "set_speed":
        try:
            speed = int(data.get("speed"))
        except (TypeError, ValueError):
            return jsonify({"error": "Speed must be a number"}), 400

        if not 0 <= speed <= 100:
            return jsonify({"error": "Speed must be between 0 and 100"}), 400

        if speed > 0 and not can_move():
            return jsonify({"error": "Safety condition prevents movement"}), 400

        agv["speed"] = speed

    elif action == "forward":
        if not can_move():
            return jsonify({"error": "Movement blocked by safety system"}), 400

        if agv["direction"] == "NORTH":
            agv["y"] += 1
        elif agv["direction"] == "SOUTH":
            agv["y"] -= 1
        elif agv["direction"] == "EAST":
            agv["x"] += 1
        else:
            agv["x"] -= 1

        agv["distance"] += 1

    elif action == "backward":
        if not can_move():
            return jsonify({"error": "Movement blocked by safety system"}), 400

        if agv["direction"] == "NORTH":
            agv["y"] -= 1
        elif agv["direction"] == "SOUTH":
            agv["y"] += 1
        elif agv["direction"] == "EAST":
            agv["x"] -= 1
        else:
            agv["x"] += 1

        agv["distance"] += 1

    elif action == "left":
        directions = ["NORTH", "WEST", "SOUTH", "EAST"]
        index = directions.index(agv["direction"])
        agv["direction"] = directions[(index + 1) % 4]

    elif action == "right":
        directions = ["NORTH", "EAST", "SOUTH", "WEST"]
        index = directions.index(agv["direction"])
        agv["direction"] = directions[(index + 1) % 4]

    elif action == "obstacle_on":
        agv["obstacle"] = True
        agv["speed"] = 0

    elif action == "obstacle_off":
        agv["obstacle"] = False

    elif action == "emergency":
        agv["emergency"] = True
        agv["speed"] = 0

    elif action == "reset":
        agv["emergency"] = False

    else:
        return jsonify({"error": "Unknown command"}), 400

    return get_state()


if __name__ == "__main__":
    app.run(debug=True, port=5000)
